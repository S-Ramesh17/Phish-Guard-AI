# PhishGuard Browser Extension - Replit Project

## Project Overview
PhishGuard is a Manifest V3 browser extension with ML-powered phishing detection. It includes:
- Client-side browser extension with real-time inference
- Python ML training pipeline with XGBoost
- Flask API for remote inference (optional)

## Project Structure
- `extension/` - Browser extension code (JavaScript, Manifest V3)
- `ml_pipeline/` - ML model training (Python, XGBoost)
- `api/` - Flask API server for remote inference

## Recent Changes
- **2025-11-14**: Initial project creation
  - Implemented Manifest V3 extension with content script and background worker
  - Created feature extraction logic (URL + DOM analysis)
  - Built warning modal UI with full-screen overlay
  - Developed XGBoost training pipeline with evaluation metrics
  - Set up Flask API with JWT authentication placeholders
  - Configured privacy-preserving telemetry

## User Preferences
None specified yet.

## Development Guidelines
- NFR-1: All inference must complete in <250ms
- NFR-3: Privacy first - only hash domains, never send raw content
- Use Python 3.11 for ML pipeline
- Extension follows Manifest V3 specifications
- All code is fully commented for production use

## Running the Project
1. **Train Model**: `python ml_pipeline/train_phish_model.py`
2. **Run API**: `python api/server_api.py` (starts on port 5000)
3. **Load Extension**: Load `extension/` directory in Chrome/Edge developer mode

## Dependencies
- Python: pandas, scikit-learn, xgboost, flask, flask-cors, pyjwt
- Browser: Chrome/Edge with Manifest V3 support
