"""
PhishGuard Remote Inference API Server

This Flask server provides a remote inference endpoint for phishing detection.
Used when client-side model is unavailable or for enterprise deployments.

NFR Compliance:
- HTTPS-only communication (NFR-3)
- JWT authentication for enterprise users (SRS 5.10.2)
- <250ms response time target (NFR-1)

Security Features:
- Token-based authentication
- CORS protection
- Rate limiting (placeholder)
- HTTPS enforcement
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import json
import time
import hashlib
from functools import wraps

app = Flask(__name__)

CORS(app, resources={
    r"/api/*": {
        "origins": ["chrome-extension://*"],
        "methods": ["POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"]
    }
})

MOCK_MODEL = {
    'version': 'v1.5_heavy',
    'features': [
        'url_length', 'num_dots', 'has_at_symbol', 'path_depth',
        'domain_entropy', 'num_forms', 'has_password_field',
        'is_https', 'suspicious_tld'
    ],
    'threshold': 0.7
}


def verify_jwt_token(token):
    """
    Verifies JWT token for enterprise authentication.
    
    In production, this would:
    1. Decode the JWT using secret key
    2. Verify signature and expiration
    3. Check user permissions and rate limits
    4. Log authentication attempts
    
    Args:
        token (str): JWT token from Authorization header
        
    Returns:
        dict: User information if valid, None otherwise
    """
    if not token or not token.startswith('Bearer '):
        return None
    
    token_value = token.replace('Bearer ', '')
    
    if token_value == 'mock_enterprise_token':
        return {
            'user_id': 'enterprise_user_001',
            'org_id': 'org_abc123',
            'tier': 'enterprise',
            'rate_limit': 10000
        }
    
    return None


def require_auth(f):
    """
    Decorator to enforce JWT authentication on endpoints.
    
    SRS 5.10.2: Enterprise users must authenticate via JWT.
    """
    @wraps(f)
    def decorated_function(*args, **kwargs):
        auth_header = request.headers.get('Authorization')
        
        user_info = verify_jwt_token(auth_header)
        
        if not user_info:
            return jsonify({
                'error': 'Unauthorized',
                'message': 'Valid JWT token required for API access'
            }), 401
        
        request.user_info = user_info
        
        return f(*args, **kwargs)
    
    return decorated_function


def remote_model_predict(features):
    """
    Runs inference using the remote (heavy) model.
    
    This simulates a more sophisticated model than the client-side version,
    with additional features and better accuracy.
    
    Args:
        features (dict): Feature vector from client
        
    Returns:
        dict: Prediction with score, reasons, and metadata
    """
    score = 0.0
    reasons = []
    
    if features.get('url_length', 0) > 75:
        score += 0.2
        reasons.append('Unusually long URL detected')
    
    if features.get('num_dots', 0) > 4:
        score += 0.25
        reasons.append('Excessive subdomain nesting')
    
    if features.get('has_at_symbol', False):
        score += 0.3
        reasons.append('URL contains @ symbol (credential phishing)')
    
    if features.get('domain_entropy', 0) > 4.0:
        score += 0.15
        reasons.append('High domain randomness (generated domain)')
    
    if features.get('suspicious_tld', False):
        score += 0.2
        reasons.append('Suspicious top-level domain')
    
    if not features.get('is_https', False) and features.get('has_password_field', False):
        score += 0.25
        reasons.append('Password field on insecure HTTP')
    
    score = min(score, 1.0)
    
    if not reasons:
        reasons = ['No significant risk factors detected']
    
    return {
        'score': score,
        'is_phishing': score >= MOCK_MODEL['threshold'],
        'reasons': reasons[:3],
        'confidence': score
    }


@app.route('/api/score', methods=['POST', 'OPTIONS'])
@require_auth
def score_endpoint():
    """
    POST /api/score
    
    Remote inference endpoint for phishing detection.
    
    Request Body:
    {
        "features": {
            "url_length": 120,
            "num_dots": 5,
            "has_at_symbol": true,
            ...
        }
    }
    
    Response:
    {
        "score": 0.85,
        "is_phishing": true,
        "reasons": [...],
        "model_version": "v1.5_heavy",
        "latency_ms": 45
    }
    
    Headers:
    - Authorization: Bearer <JWT_TOKEN> (required)
    """
    if request.method == 'OPTIONS':
        return '', 204
    
    start_time = time.time()
    
    try:
        data = request.get_json()
        
        if not data or 'features' not in data:
            return jsonify({
                'error': 'Bad Request',
                'message': 'Missing "features" in request body'
            }), 400
        
        features = data['features']
        
        result = remote_model_predict(features)
        
        end_time = time.time()
        latency_ms = (end_time - start_time) * 1000
        
        response = {
            'score': result['score'],
            'is_phishing': result['is_phishing'],
            'reasons': result['reasons'],
            'confidence': result['confidence'],
            'model_version': MOCK_MODEL['version'],
            'latency_ms': round(latency_ms, 2),
            'timestamp': int(time.time())
        }
        
        if latency_ms > 250:
            app.logger.warning(
                f'NFR-1 VIOLATION: API latency {latency_ms:.2f}ms exceeds 250ms threshold'
            )
        
        app.logger.info(
            f'Inference completed: score={result["score"]:.2f}, '
            f'latency={latency_ms:.2f}ms, user={request.user_info["user_id"]}'
        )
        
        return jsonify(response), 200
        
    except Exception as e:
        app.logger.error(f'Inference error: {str(e)}')
        return jsonify({
            'error': 'Internal Server Error',
            'message': 'Failed to process inference request'
        }), 500


@app.route('/api/health', methods=['GET'])
def health_check():
    """
    GET /api/health
    
    Health check endpoint for monitoring.
    """
    return jsonify({
        'status': 'healthy',
        'model_version': MOCK_MODEL['version'],
        'timestamp': int(time.time())
    }), 200


@app.route('/api/model-info', methods=['GET'])
@require_auth
def model_info():
    """
    GET /api/model-info
    
    Returns information about the deployed model.
    Requires authentication.
    """
    return jsonify({
        'version': MOCK_MODEL['version'],
        'features': MOCK_MODEL['features'],
        'threshold': MOCK_MODEL['threshold'],
        'type': 'XGBoost Heavy Model',
        'deployment_date': '2025-11-14'
    }), 200


if __name__ == '__main__':
    print("="*60)
    print("PhishGuard Remote Inference API Server")
    print("="*60)
    print("\nNOTE: This server is configured for DEVELOPMENT ONLY")
    print("For production deployment:")
    print("  1. Enable HTTPS with valid SSL certificate")
    print("  2. Configure real JWT secret key")
    print("  3. Use production WSGI server (gunicorn, uwsgi)")
    print("  4. Enable rate limiting and request validation")
    print("  5. Set up proper logging and monitoring")
    print("\n" + "="*60 + "\n")
    
    app.run(
        host='0.0.0.0',
        port=5000,
        debug=True
    )
