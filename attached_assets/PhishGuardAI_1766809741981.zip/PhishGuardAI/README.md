# PhishGuard Browser Extension

**PhishGuard** is a production-quality, ML-powered browser extension that detects phishing websites in real-time using client-side inference with a lightweight XGBoost model.

## 🎯 Project Overview

PhishGuard provides comprehensive phishing protection through:
- **Client-side ML inference** (<250ms latency)
- **Privacy-preserving telemetry** (hashed domains only)
- **Explainable AI** (top 3 risk reasons)
- **Full-screen warning modals** with user actions
- **Optional remote inference API** for enterprise deployments

## 📁 Project Structure

```
PhishGuard/
├── extension/              # Browser extension (Manifest V3)
│   ├── manifest.json      # Extension configuration
│   └── dist/
│       ├── content.js     # Feature extraction & UI injection
│       └── background.js  # Model inference & orchestration
├── ml_pipeline/           # ML model training
│   └── train_phish_model.py
├── api/                   # Remote inference server
│   └── server_api.py
└── requirements.txt       # Python dependencies
```

## 🚀 Quick Start

### 1. Train the ML Model

```bash
cd ml_pipeline
python train_phish_model.py
```

This will:
- Create a mock dataset with phishing and legitimate URLs
- Engineer features (URL length, domain entropy, form count, etc.)
- Train an XGBoost classifier
- Export the model to `phishing_model.json`
- Display evaluation metrics (Accuracy, F1, Precision, Recall)

### 2. Load Extension in Browser

**Chrome/Edge:**
1. Open `chrome://extensions/` or `edge://extensions/`
2. Enable "Developer mode" (top-right toggle)
3. Click "Load unpacked"
4. Select the `extension/` directory
5. The PhishGuard icon should appear in your toolbar

**Testing:**
- Visit a legitimate site → No warning
- Visit a URL with phishing patterns → Warning modal appears

### 3. Run the API Server (Optional)

For remote inference or enterprise deployments:

```bash
cd api
python server_api.py
```

The server will start on `http://0.0.0.0:5000`

**Endpoints:**
- `POST /api/score` - Remote inference (requires JWT auth)
- `GET /api/health` - Health check
- `GET /api/model-info` - Model information (requires auth)

**Testing with cURL:**
```bash
curl -X POST http://localhost:5000/api/score \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer mock_enterprise_token" \
  -d '{
    "features": {
      "url_length": 120,
      "num_dots": 5,
      "has_at_symbol": true,
      "path_depth": 6,
      "num_forms": 3,
      "has_password_field": true
    }
  }'
```

## 🔧 Technical Details

### NFR Compliance

| Requirement | Implementation | Status |
|-------------|---------------|--------|
| **NFR-1: Latency <250ms** | Client-side inference with lightweight model | ✅ |
| **NFR-3: Privacy** | Domain hashing, no raw content transmitted | ✅ |
| **SRS 5.10.2: Authentication** | JWT token verification for API | ✅ |

### Features Extracted

**URL Features:**
- `url_length` - Total URL character count
- `num_dots` - Number of dot characters (subdomain nesting)
- `has_at_symbol` - Presence of @ symbol (credential phishing)
- `path_depth` - URL path hierarchy depth

**DOM Features:**
- `num_forms` - Number of HTML forms
- `has_password_field` - Presence of password input fields

**Advanced Features (ML Pipeline):**
- `domain_entropy` - Shannon entropy of domain name
- `is_https` - Protocol security indicator
- `suspicious_tld` - Known phishing TLD detection

### ML Model

- **Algorithm:** XGBoost Classifier
- **Training:** Scikit-learn pipeline with stratified split
- **Evaluation Metrics:**
  - Accuracy
  - F1-Score
  - Precision
  - Recall
- **Export Format:** JSON (browser-compatible)

### Security Features

**Extension:**
- Content Security Policy enforcement
- Minimal permissions (scripting, storage, activeTab, tabs)
- No external network requests from content scripts

**API Server:**
- JWT authentication for enterprise users
- CORS protection (chrome-extension:// origins)
- HTTPS enforcement (production)
- Rate limiting (placeholder)

## 📊 Usage Example

### Client-Side Detection Flow

1. **User visits webpage** → Content script loads
2. **Feature extraction** → `extractClientFeatures()` analyzes DOM and URL
3. **Send to background** → `chrome.runtime.sendMessage()`
4. **Inference** → Background worker runs `runLocalInference()`
5. **Result** → If phishing detected (score > 0.7):
   - Full-screen modal injected
   - User shown confidence score + top 3 reasons
   - Options: Go Back, Proceed Anyway, Report False Positive

### Warning Modal

```
⚠️ Phishing Detected!

Confidence Score: 85.0%

Why we flagged this site:
• URL contains @ symbol (credential phishing pattern)
• Excessive subdomain nesting detected
• Password field on insecure HTTP connection

This website may be attempting to steal your personal information...

[← Go Back to Safety] [Proceed Anyway] [Report as Safe Site]
```

## 🛠️ Development

### Prerequisites
- Python 3.11+
- Chrome/Edge browser (Manifest V3 support)
- Node.js (optional, for extension bundling)

### Python Dependencies

```bash
pip install -r requirements.txt
```

**Core Libraries:**
- `pandas` - Data manipulation
- `scikit-learn` - ML pipeline
- `xgboost` - Gradient boosting
- `flask` - API server
- `flask-cors` - CORS handling
- `pyjwt` - JWT authentication

### Extension Development

**File Watching:**
For active development, use a file watcher to reload the extension on changes:
```bash
npm install -g web-ext
web-ext run --source-dir=extension/
```

**Testing:**
- Test on known phishing URLs (PhishTank, OpenPhish)
- Verify latency stays <250ms
- Check modal UI responsiveness
- Test false positive reporting

## 🔮 Future Enhancements

### Next Phase Features
1. **Production Model Training**
   - Real dataset integration (PhishTank, OpenPhish)
   - Hyperparameter tuning with Grid/Random Search
   - Cross-validation for robustness

2. **Enhanced Security**
   - Real JWT authentication with refresh tokens
   - Role-based access control (RBAC)
   - API rate limiting with Redis

3. **User Dashboard**
   - Flagged site history
   - False positive review system
   - Analytics and statistics

4. **Advanced ML**
   - Model versioning and A/B testing
   - Online learning for model updates
   - Ensemble methods (Random Forest + XGBoost)

5. **Performance Optimizations**
   - WASM model compilation for faster inference
   - IndexedDB caching for model artifacts
   - Service worker optimization

## 📝 License

This is a demonstration/skeleton project for educational purposes.

## 🤝 Contributing

This is a production-quality skeleton designed for extension and customization.

### Key Extension Points:
- Replace mock dataset with real phishing data
- Implement actual JWT secret management
- Add comprehensive test suite
- Deploy API with HTTPS and production WSGI server
- Integrate with real telemetry backend

## 📞 Support

For issues or questions:
1. Check the code comments (fully documented)
2. Review the NFR compliance matrix
3. Test with mock data first
4. Verify browser console for errors

---

**Built with privacy and security in mind. Stay safe online! 🛡️**
