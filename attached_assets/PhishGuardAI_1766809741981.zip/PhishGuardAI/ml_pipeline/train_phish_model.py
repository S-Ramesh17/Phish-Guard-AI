"""
PhishGuard ML Model Training Pipeline

This script demonstrates the complete ML workflow for phishing detection:
1. Dataset creation (mock data for demonstration)
2. Feature engineering from raw URL and DOM data
3. Model training using XGBoost
4. Evaluation with required metrics (Accuracy, F1, Precision, Recall)
5. Model export to JSON for browser deployment

NFR Compliance:
- Model optimized for <250ms inference latency
- Privacy-preserving feature extraction (no raw content)
"""

import pandas as pd
import numpy as np
import json
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
import xgboost as xgb
from urllib.parse import urlparse
import math


def create_mock_dataset():
    """
    Creates a mock dataset for phishing detection training.
    
    In production, this would be replaced with a real dataset from sources like:
    - PhishTank
    - OpenPhish
    - Common Crawl (legitimate sites)
    
    Returns:
        pd.DataFrame: Mock dataset with URLs, DOM data, and labels
    """
    data = {
        'url': [
            'http://paypal-secure-login.xyz/account/verify?token=abc123',
            'https://www.amazon.com/products/electronics',
            'https://www.google.com/search?q=python',
            'http://banking-update@malicious.com/login.php',
            'https://github.com/username/repository',
            'http://secure-apple-id.co/verify/account.html',
            'https://stackoverflow.com/questions/12345',
            'http://login.facebook.phishing.net/signin',
            'https://www.wikipedia.org/wiki/Machine_Learning',
            'http://netflix-billing.ru/update-payment-info.php'
        ],
        'num_forms': [3, 0, 1, 2, 0, 4, 1, 3, 0, 2],
        'has_password_field': [True, False, False, True, False, True, False, True, False, True],
        'label': [1, 0, 0, 1, 0, 1, 0, 1, 0, 1]
    }
    
    return pd.DataFrame(data)


def calculate_domain_entropy(domain):
    """
    Calculates Shannon entropy of a domain name.
    Higher entropy often indicates randomly generated phishing domains.
    
    Args:
        domain (str): Domain name
        
    Returns:
        float: Shannon entropy value
    """
    if not domain:
        return 0.0
    
    char_counts = {}
    for char in domain:
        char_counts[char] = char_counts.get(char, 0) + 1
    
    entropy = 0.0
    domain_len = len(domain)
    
    for count in char_counts.values():
        probability = count / domain_len
        entropy -= probability * math.log2(probability)
    
    return entropy


def feature_engineer(df):
    """
    Expands raw data into comprehensive feature set for ML model.
    
    Features extracted:
    - URL length (phishing URLs often very long)
    - Number of dots (excessive subdomains)
    - Has @ symbol (credential phishing pattern)
    - Path depth (hiding true destination)
    - Domain entropy (randomness indicator)
    - Number of forms (data harvesting)
    - Has password field (credential theft)
    - Is HTTPS (security indicator)
    - Suspicious TLD (common phishing extensions)
    
    Args:
        df (pd.DataFrame): Raw dataset
        
    Returns:
        pd.DataFrame: Engineered feature set
    """
    features_df = df.copy()
    
    features_df['url_length'] = features_df['url'].apply(len)
    
    features_df['num_dots'] = features_df['url'].apply(lambda x: x.count('.'))
    
    features_df['has_at_symbol'] = features_df['url'].apply(lambda x: int('@' in x))
    
    def get_path_depth(url):
        parsed = urlparse(url)
        path_parts = [p for p in parsed.path.split('/') if p]
        return len(path_parts)
    
    features_df['path_depth'] = features_df['url'].apply(get_path_depth)
    
    def get_domain(url):
        parsed = urlparse(url)
        return parsed.netloc
    
    features_df['domain'] = features_df['url'].apply(get_domain)
    features_df['domain_entropy'] = features_df['domain'].apply(calculate_domain_entropy)
    
    features_df['is_https'] = features_df['url'].apply(lambda x: int(x.startswith('https://')))
    
    suspicious_tlds = ['.xyz', '.tk', '.ml', '.ga', '.cf', '.ru', '.cc']
    features_df['suspicious_tld'] = features_df['url'].apply(
        lambda x: int(any(x.endswith(tld) for tld in suspicious_tlds))
    )
    
    features_df['has_password_field'] = features_df['has_password_field'].astype(int)
    
    return features_df


def train_phishing_model(df):
    """
    Trains XGBoost classifier for phishing detection.
    
    Args:
        df (pd.DataFrame): Engineered feature dataset
        
    Returns:
        tuple: (trained model, feature columns, test data, predictions)
    """
    feature_columns = [
        'url_length',
        'num_dots',
        'has_at_symbol',
        'path_depth',
        'domain_entropy',
        'num_forms',
        'has_password_field',
        'is_https',
        'suspicious_tld'
    ]
    
    X = df[feature_columns]
    y = df['label']
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.3, random_state=42, stratify=y
    )
    
    model = xgb.XGBClassifier(
        n_estimators=50,
        max_depth=4,
        learning_rate=0.1,
        subsample=0.8,
        colsample_bytree=0.8,
        random_state=42,
        eval_metric='logloss'
    )
    
    print("Training XGBoost model...")
    model.fit(X_train, y_train)
    
    y_pred = model.predict(X_test)
    
    return model, feature_columns, (X_test, y_test), y_pred


def evaluate_model(y_test, y_pred):
    """
    Evaluates model performance using required metrics.
    
    Required Metrics (per specifications):
    - Accuracy
    - F1-Score
    - Precision
    - Recall
    
    Args:
        y_test: True labels
        y_pred: Predicted labels
    """
    accuracy = accuracy_score(y_test, y_pred)
    f1 = f1_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred)
    recall = recall_score(y_test, y_pred)
    
    print("\n" + "="*50)
    print("MODEL EVALUATION METRICS")
    print("="*50)
    print(f"Accuracy:  {accuracy:.4f} ({accuracy*100:.2f}%)")
    print(f"F1-Score:  {f1:.4f}")
    print(f"Precision: {precision:.4f}")
    print(f"Recall:    {recall:.4f}")
    print("="*50 + "\n")
    
    return {
        'accuracy': accuracy,
        'f1_score': f1,
        'precision': precision,
        'recall': recall
    }


def export_model_to_json(model, feature_columns, metrics, output_path='phishing_model.json'):
    """
    Exports trained model to JSON format for browser deployment.
    
    The JSON format is preferred for browser-side deployment because:
    - Lightweight and parseable in JavaScript
    - No need for WASM compilation
    - Easy to version and update
    
    Args:
        model: Trained XGBoost model
        feature_columns: List of feature names
        metrics: Evaluation metrics dictionary
        output_path: Path to save JSON file
    """
    feature_importance = model.feature_importances_.tolist()
    
    model_json = {
        'version': 'v1.0',
        'model_type': 'XGBoostClassifier',
        'trained_date': pd.Timestamp.now().isoformat(),
        'feature_columns': feature_columns,
        'feature_importance': dict(zip(feature_columns, feature_importance)),
        'metrics': metrics,
        'hyperparameters': {
            'n_estimators': model.n_estimators,
            'max_depth': model.max_depth,
            'learning_rate': model.learning_rate
        },
        'trees': []
    }
    
    booster = model.get_booster()
    model_dump = booster.get_dump(dump_format='json')
    model_json['trees'] = [json.loads(tree) for tree in model_dump]
    
    with open(output_path, 'w') as f:
        json.dump(model_json, f, indent=2)
    
    print(f"Model exported to: {output_path}")
    print(f"File size: {len(json.dumps(model_json)) / 1024:.2f} KB")
    
    return model_json


def main():
    """
    Main training pipeline execution.
    """
    print("PhishGuard ML Training Pipeline")
    print("=" * 50)
    
    print("\n1. Creating mock dataset...")
    df = create_mock_dataset()
    print(f"   Dataset size: {len(df)} samples")
    print(f"   Phishing: {df['label'].sum()}, Legitimate: {len(df) - df['label'].sum()}")
    
    print("\n2. Engineering features...")
    df_features = feature_engineer(df)
    print(f"   Features extracted: {len(df_features.columns) - 2}")
    
    print("\n3. Training model...")
    model, feature_columns, (X_test, y_test), y_pred = train_phishing_model(df_features)
    
    print("\n4. Evaluating model...")
    metrics = evaluate_model(y_test, y_pred)
    
    print("\n5. Exporting model to JSON...")
    model_json = export_model_to_json(model, feature_columns, metrics)
    
    print("\n✓ Training pipeline completed successfully!")
    print(f"  Model version: {model_json['version']}")
    print(f"  Ready for browser deployment")


if __name__ == '__main__':
    main()
